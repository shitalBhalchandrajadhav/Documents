﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsPF
{
    class thread1
    {

        public void run()
        {
            int iterations = 10;
            try
            {
                for (int i = 0; i < iterations; i++)
                {
                    Console.WriteLine("From Thread1");
                    Thread.Sleep(2000);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
    }
}
