﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;
using System.Threading;
using System.Windows.Threading;


namespace WindowsPF
{
    /// <summary>
    /// Interaction logic for mainwindow.xaml
    /// </summary>
    public partial class mainwindow : Window
    {
        public mainwindow()
        {
            InitializeComponent();


        }

        private async void button_Click(object sender, RoutedEventArgs e)
        {



            //            OpenFileDialog t = new OpenFileDialog();
            //                t.DefaultExt = ".txt";
            //               t.Filter = "Text Document (.txt)|*.txt";
            //            //    //FileStream f = new FileStream("d:\\demo.txt", FileMode.Create);
            //            //    //StreamWriter s = new StreamWriter(f);
            //            //    //s.WriteLine("using WPF ,C#, .Net,THresding etc");
            //            //    //s.Close();
            //            //    //f.Close();
            //            //    //Console.WriteLine("File Created Succesfully...");



            //            //    if (t.ShowDialog() == true)
            //            //    {


            //            //        string filename = t.FileName;
            //            //        textBox.Text = filename;
            //            //       // textBox1.Text = File.ReadAllText(filename);
            //            //        string[] list = File.ReadAllLines(filename);

            //            //        foreach (var item in list)
            //            //        {
            //            //            Thread.Sleep(2000);     // sec

            //            //            textBox1.AppendText(item);


            //            //        }


          
            OpenFileDialog fileExplorer = new OpenFileDialog();
            if (fileExplorer.ShowDialog() is true)
            {
                textBox.Text = fileExplorer.FileName;
                foreach (var line in await File.ReadAllLinesAsync(fileExplorer.FileName, Encoding.UTF8))
                {
                    await Task.Delay(1000);
                    textBox1.AppendText(line);
                }
            }
        }
    }
}