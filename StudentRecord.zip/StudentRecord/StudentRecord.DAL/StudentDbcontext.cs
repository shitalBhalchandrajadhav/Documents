﻿using Microsoft.EntityFrameworkCore;
using StudentRecord.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentRecord.DAL
{
   public  class StudentDbcontext : DbContext
    { 
            public StudentDbcontext(DbContextOptions<StudentDbcontext> options) : base(options)
            {

            }
            public DbSet<Student> StudentRecordFile{ get; set; }
        
   }
}
