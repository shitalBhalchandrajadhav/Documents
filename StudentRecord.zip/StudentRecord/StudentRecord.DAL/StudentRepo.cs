﻿using Microsoft.EntityFrameworkCore;
using StudentRecord.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentRecord.DAL
{
    public class StudentRepo
    {
        private readonly StudentDbcontext _context;
        public StudentRepo(StudentDbcontext context)
        {
            _context = context;
        }
        public async Task<List<Student>> GetStudent()
        {
            return await _context.StudentRecordFile.ToListAsync();
        }
        public async Task<Student> GetStudent(Guid Id)
        {
            var student = await _context.StudentRecordFile.FindAsync(Id);
            return student;
        }

        public async Task<Student> SaveStudent(Student studentObj)
        {
            try
            {
                _context.StudentRecordFile.Add(studentObj);
                await _context.SaveChangesAsync();
                return studentObj;
            }
            catch
            {
                Console.WriteLine("not Succesfully");
                throw new Exception();
            }

        }

        public async Task UpdateStudent(Student student)
        {

            _context.StudentRecordFile.Update(student);
            await _context.SaveChangesAsync();
            _context.Entry(student).State = EntityState.Detached;

        }




        public async Task DeleteStudent(Guid Id)
        {
            try
            {
                var student = await _context.StudentRecordFile.FindAsync(Id);
                if (student == null)
                    throw new Exception("Invalid id");
                _context.StudentRecordFile.Remove(student);
                await _context.SaveChangesAsync();
            }
            catch(Exception e)
            {
                Console.WriteLine("Not Delete");
            }
        }
    }
}
