﻿using StudentRecord.Model;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace StudentRecord.IBL
{
    public  interface IStudentService
    {
        // Create 
        
        //Task<Student> SaveStudent(SaveStudentRequest student);

        //Task CreateStudent(CreateStudentRequest student);

        // get list of all 

        Task<IEnumerable<Student>> GetStudentList();

        // get  details by  id
        Task<StudentDto> GetStudentDetailsById(Guid Id);

        // update
        Task UpdateStudent(Student student);

        // delete 
        Task DeleteStudent(Guid Id);
        Task<Student> SaveStudent(StudentCreateDto createRequest);
   }
}
