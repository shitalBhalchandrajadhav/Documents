﻿namespace StudentRecord.Model
{
    public class StudentCreateDto
    {
        public string Name { get; set; }
        public string Address { get; set; }
    }

}
