﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using StudentRecord.DAL;
using StudentRecord.IBL;
using StudentRecord.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentRecord.BLL
{
    public class StudentService : IStudentService
    {
        private readonly StudentRepo _stuentRepo;
        private readonly IMapper _mapper;
        private object _context;

        public StudentService(StudentRepo stuentRepo, IMapper mapper)
        {
            _stuentRepo = stuentRepo;
            _mapper = mapper;
        }
        public async Task DeleteStudent(Guid Id)
        {
            await _stuentRepo.DeleteStudent(Id);

        }

        public async Task<Student> SaveStudent(StudentCreateDto createRequest)
        {
            try
            {
                var requestObj = _mapper.Map<Student>(createRequest);
                var stud1 = await _stuentRepo.SaveStudent(requestObj);
                return stud1;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public async Task<StudentDto> GetStudentDetailsById(Guid Id)
        {
            var stud = await _stuentRepo.GetStudent(Id);
            var result = _mapper.Map<StudentDto>(stud);
            return result;
        }

        public async Task<IEnumerable<Student>> GetStudentList()
        {
            var studList = await _stuentRepo.GetStudent();
            return studList;
        }

        public async Task UpdateStudent(Student student)
        {
            //var stud = await _stuentRepo.GetStudent(Id);
            //if (stud != null)
            ////   throw new Exception("Invalid id");
            //stud.Name = student.Name;
            //stud.Address = student.Address;
            ////_context.StudentRecord.Update(student);
            ////_context.Entry(stud).State = EntityState.Modified;
            ////await _context.SaveChangesAsync();

            //await _stuentRepo.UpdateStudent(student);



            var stud = await _stuentRepo.GetStudent(student.ID);
            if (stud != null)
                try
                {
                    stud.Name = student.Name;
                    stud.Address = student.Address;
                    await _stuentRepo.UpdateStudent(stud);
                }
                catch (Exception e)
                {
                    throw e;
                }

        }
    }
}
