﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StudentRecord.IBL;
using StudentRecord.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentRecord.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentContoller : ControllerBase
    {


        private readonly IStudentService _studentService;

        public StudentContoller(IStudentService service)
        {
            _studentService = service;

        }


        // Get all student

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Student>>> GetStudentList()
        { 
            var student = await _studentService.GetStudentList();
            return Ok(student);
        }


        // Get using Id
        [HttpGet("{id}")]
        public async Task<ActionResult> GetStudentById(Guid id)
        {
            try{ 
          
                var student = await _studentService.GetStudentDetailsById( id);
                return Ok(student);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        // create 
       [HttpPost]
        public async Task<ActionResult<Student>> CreateStudent(StudentCreateDto student)
        {
            var model = await _studentService.SaveStudent(student);
            return Ok(model);
        }


        // Update
        [HttpPut]
        public async Task<IActionResult>UpdateStudent( Student updateStudent)
        {
            try
            {
                await _studentService.UpdateStudent(updateStudent);
                return Ok();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        [HttpDelete]
        public async Task <IActionResult> DeleteStudent(Guid id)
        {


            await _studentService.DeleteStudent(id);
            return Ok();
            
        }


    }
}
