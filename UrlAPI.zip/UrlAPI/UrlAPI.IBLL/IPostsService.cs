﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UrlAPI.Model;

namespace UrlAPI.IBLL
{
   public interface  IPostsService
    {
        Task<bool> CreatePosts();
        Task<List<Postss>> GetPosts();
    }
}
