﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UrlAPI.DAL;
using UrlAPI.Model;

namespace UrlAPI.IBLL
{
   public  interface IAlbumService
   {
        Task<bool> CreateAlbumss();
        Task<List<Albumss>> GetAlbumss();
   }
}
