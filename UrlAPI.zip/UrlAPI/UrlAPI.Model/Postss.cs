﻿using System;
using System.Collections.Generic;

#nullable disable

namespace UrlAPI.Model
{
    public partial class Postss
    {
        public int UserId { get; set; }
        public int Id { get; set; }
        public string Title { get; set; }
        public string Body { get; set; }
    }
}
