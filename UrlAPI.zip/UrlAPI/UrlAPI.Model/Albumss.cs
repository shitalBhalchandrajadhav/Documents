﻿using System;
using System.Collections.Generic;

#nullable disable

namespace UrlAPI.Model
{
    public partial class Albumss
    {
        public int? UserId { get; set; }
        public int Id { get; set; }
        public string Title { get; set; }
    }
}
