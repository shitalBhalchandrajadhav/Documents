﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UrlAPI.Model
{
   public  class Config
    {
        public string urlalbum { get; set; }
        public string urlposts { get; set; }
    }
}
