﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UrlAPI.BLL;
using UrlAPI.IBLL;

namespace UrlAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AlbumController : ControllerBase
    {


        private readonly IAlbumService  _albumService;

        public AlbumController(IAlbumService albumService)
        {
            _albumService = albumService;
        }


        [HttpPost("CreateAlbum")]
        public async Task<ActionResult> CreateTodo()
        {
            var model = await _albumService.CreateAlbumss();
            return Ok(model);
        }

        [HttpGet("Getalbum")]
        public async Task<ActionResult> GetAlbumss()
        {
            var model = await _albumService.GetAlbumss();
            return Ok(model);
        }

        

    }
}
