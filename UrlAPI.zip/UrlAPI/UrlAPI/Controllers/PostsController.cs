﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UrlAPI.IBLL;

namespace UrlAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostsController : ControllerBase
    {


        private readonly IPostsService _postsService;

        public PostsController(IPostsService postsService)
        {
            _postsService = postsService;
        }


        [HttpPost("Createposts")]
        public async Task<ActionResult> CreatePosts()
        {
            var model = await _postsService.CreatePosts();
            return Ok(model);
        }

        [HttpGet("Getposts")]
        public async Task<ActionResult> GetPosts()
        {
            var model = await _postsService.GetPosts();
            return Ok(model);
        }


    }
}
