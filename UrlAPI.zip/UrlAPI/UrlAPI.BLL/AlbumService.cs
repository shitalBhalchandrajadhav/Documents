﻿using AutoMapper;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

using UrlAPI.DAL.Repo;
using UrlAPI.IBLL;
using UrlAPI.Model;

namespace UrlAPI.BLL
{
    public class AlbumService : IAlbumService
    {
        private readonly AlbumRepo _albumRepo;
        private readonly IMapper mapper;
        private readonly Config _config;
        public AlbumService(AlbumRepo albumRepo, IMapper mapper, IOptions<Config> Config)
        {
            _albumRepo = albumRepo;
            this.mapper = mapper;
            _config = Config.Value;
        }


        async Task<string> ExecuteGetRequest(string url)
        {
            using var client = new HttpClient();
            client.DefaultRequestHeaders.Add("Accept", "application/json");

            var apiresponse = await client.GetAsync(new Uri(url));
            if (apiresponse.IsSuccessStatusCode)
            {
                string result = await apiresponse.Content.ReadAsStringAsync();
                return result;
            }
            throw new Exception("Api Failed");
        }

        public async Task<bool> CreateAlbumss()
        {
            var urlalbum = _config.urlalbum;
            var res = await ExecuteGetRequest(urlalbum);
            var model = JsonConvert.DeserializeObject<List<Albumss>>(res);
            var isSuccess = await _albumRepo.CreateAlbumss(model);
            if (isSuccess is true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public async Task<List<Albumss>> GetAlbumss()
        {
            var result = await _albumRepo.GetAlbumss();
            return result;
        }
    }
}
