﻿using AutoMapper;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using UrlAPI.DAL;
using UrlAPI.DAL.Repo;
using UrlAPI.IBLL;
using UrlAPI.Model;

namespace UrlAPI.BLL
{
   public  class PostsService :IPostsService
    {

        private readonly PostsRepo _postsRepo;
        private readonly IMapper mapper;
        private readonly Config _config;
        public PostsService(PostsRepo postsRepo, IMapper mapper, IOptions<Config> Config)
        {
            _postsRepo = postsRepo;
            this.mapper = mapper;
            _config = Config.Value;
        }


        async Task<string> ExecuteGetRequest(string url)
        {
            using var client = new HttpClient();
            client.DefaultRequestHeaders.Add("Accept", "application/json");

            var apiresponse = await client.GetAsync(new Uri(url));
            if (apiresponse.IsSuccessStatusCode)
            {
                string result = await apiresponse.Content.ReadAsStringAsync();
                return result;
            }
            throw new Exception("Api Failed");
        }

        public async Task<bool> CreatePosts()
        {
            var urlposts = _config.urlposts;
            var res = await ExecuteGetRequest(urlposts);
            var model = JsonConvert.DeserializeObject<List<Postss>>(res);
            var isSuccess = await _postsRepo.CreatePosts(model);
            if (isSuccess is true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public async  Task<List<Postss>> GetPosts()
        {
            var result = await _postsRepo.GetPosts();
            return result;
        }
    }
}
