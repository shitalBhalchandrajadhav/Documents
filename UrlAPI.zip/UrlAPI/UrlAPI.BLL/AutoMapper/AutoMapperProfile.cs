﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UrlAPI.DAL;
using UrlAPI.Model;

namespace UrlAPI.BLL.AutoMapper
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {

            CreateMap<Albumss, Albumss>();
            CreateMap<Postss, Postss> ();

        }

    }
}
