﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UrlAPI.Model;

namespace UrlAPI.DAL.Repo
{
   public  class AlbumRepo
   {


        private readonly AlbumDBContext _context;

        public AlbumRepo(AlbumDBContext context)
        {
            _context = context;
        }


        public async Task<List<Albumss>> GetAlbumss()
        {
            return await _context.Albumsses.AsNoTracking().ToListAsync();
        }

        public async Task<bool> CreateAlbumss(List<Albumss> albumss)
        {
            try
            {
                await DeleteAlbumss();

                foreach (var item in albumss)
                {
                    await _context.Albumsses.AddAsync(item);
                    await _context.SaveChangesAsync();
                }
            }
            catch (Exception e)
            {
                throw new Exception("unsuess");
            }
            return true;
        }

        public async Task DeleteAlbumss()
        {
            var res = await _context.Albumsses.ToListAsync();
            if (res != null && res.Count > 0)
            {
                _context.Albumsses.RemoveRange(res);
                await _context.SaveChangesAsync();
            }
        }




    }
}
