﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UrlAPI.Model;

namespace UrlAPI.DAL.Repo
{
   public  class PostsRepo
    {



        private readonly PostsDBContext _context;

        public PostsRepo(PostsDBContext context)
        {
            _context = context;
        }


        public async Task<List<Postss>> GetPosts()
        {
            return await _context.Postsses.AsNoTracking().ToListAsync();
        }

        public async Task<bool> CreatePosts(List<Postss> postss)
        {
            try
            {
                await DeletePosts();

                foreach (var item in postss)
                {
                    await _context.Postsses.AddAsync(item);
                    await _context.SaveChangesAsync();
                }
            }
            catch (Exception e)
            {
                throw new Exception("unsuess");
            }
            return true;
        }

        public async Task DeletePosts()
        {
            var res = await _context.Postsses.ToListAsync();
            if (res != null && res.Count > 0)
            {
                _context.Postsses.RemoveRange(res);
                await _context.SaveChangesAsync();
            }
        }


    }
}
