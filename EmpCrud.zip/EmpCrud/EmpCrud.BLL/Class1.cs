﻿using System;

namespace EmpCrud.BLL
{
    public class Class1
    {
    }
}
