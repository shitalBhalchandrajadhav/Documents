﻿using System;

namespace EmpCrud.IBLL
{
    public class Class1
    {
    }
}
