﻿using System;

namespace EmpCrud.DAL
{
    public class Class1
    {
    }
}
