﻿using System;

namespace EmpCrud.Model
{
    public class Class1
    {
    }
}
