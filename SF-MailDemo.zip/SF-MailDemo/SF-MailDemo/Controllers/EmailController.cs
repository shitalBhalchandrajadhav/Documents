﻿using Microsoft.AspNetCore.Mvc;
using SF_MailDemo.IBLL;
using SF_MailDemo.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SF_MailDemo.Controllers
{
    public class EmailController : Controller
    {

        private readonly IEmailSender emailSender;
        public EmailController(IEmailSender emailSender)
        {
            this.emailSender = emailSender;
        }

        [HttpPost("Send")]
        public async Task<IActionResult> Send([FromForm] EmailConfiguration request)
        {
            try
            {
                await emailSender.SendEmailAsync(request);
                return Ok();
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }




        public IActionResult Index()
        {
            return View();
        }
    }
}
