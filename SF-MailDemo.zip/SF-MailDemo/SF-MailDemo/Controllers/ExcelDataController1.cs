﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SF_MailDemo.IBLL;
using SF_MailDemo.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SF_MailDemo.Controllers
{
    
    public class ExcelDataController1 : ControllerBase
    {
        private readonly IExcelData excelData;
        public ExcelDataController1(IExcelData excelData)
        {
            this.excelData = excelData;
        }

        [HttpPost("ExportData")]
        public IActionResult ExportData([FromForm]ExcelDatauser request)
        {
            var result = excelData.AddExcelDatauser(request);
            return File(result,
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "EmployeData.xlsx"
                        );
        }
    }
}
