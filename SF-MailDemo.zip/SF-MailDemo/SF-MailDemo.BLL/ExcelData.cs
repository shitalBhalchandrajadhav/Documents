﻿using ClosedXML.Excel;
using Microsoft.Extensions.Options;
using SF_MailDemo.IBLL;
using SF_MailDemo.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SF_MailDemo.BLL
{

    public class ExcelData : IExcelData
    {
        public byte[] AddExcelDatauser(ExcelDatauser request)
        {
            var workingDirectory = Path.Combine(Directory.GetCurrentDirectory(), "File");
            var excelPath = Path.Combine(workingDirectory, "EmployeData.xlsx");

            if (!File.Exists(excelPath))
            {
                var file = new FileStream(excelPath, FileMode.CreateNew, FileAccess.ReadWrite);
                using (var workbook = new XLWorkbook())
                {
                    var worksheet = workbook.Worksheets.Add("Employes");
                    var currentRow = 1;

                    worksheet.Cell(currentRow, 1).Value = "slno";
                    worksheet.Cell(currentRow, 2).Value = "Empname";
                    worksheet.Cell(currentRow, 3).Value = "Desg";
                    worksheet.Cell(currentRow, 4).Value = "Dept";
                    workbook.SaveAs(file, true);
                }
                file.Close();
            }

            using (var workbook = new XLWorkbook(excelPath))
            {
                var worksheet = workbook.Worksheets.First(w => w.Name == "Employes");
                var currentRow = worksheet.Rows().Count() + 1;

                worksheet.Cell(currentRow, 1).Value = request.slno;
                worksheet.Cell(currentRow, 2).Value = request.Empname;
                worksheet.Cell(currentRow, 3).Value = request.Desg;
                worksheet.Cell(currentRow, 4).Value = request.Dept;

                workbook.Save();
            }

            return DownloadFile(excelPath);
        }

    

          public byte[] DownloadFile(string filePath)
           {

                  var file = File.ReadAllBytes(filePath);
                  return file;
          }

    } 
}



