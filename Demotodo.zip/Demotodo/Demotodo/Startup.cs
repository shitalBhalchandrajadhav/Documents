using AutoMapper;
using Demotodo.BLL;
using Demotodo.BLL.AutoMapper;
using Demotodo.DAL;
using Demotodo.IBLL;
using Demotodo.Model;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Demotodo
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //services.AddDbContext<TContext>(options => options.UseSqlServer(Configuration.GetConnectionString("ConStr")));
           
            services.Configure<Config>(option=>Configuration.GetSection("Config").Bind(option));
            services.AddDbContext<TContext>(options => options.UseSqlServer(Configuration.GetConnectionString("ConStr")));
            services.AddDbContext<PhotosContext>(options => options.UseSqlServer(Configuration.GetConnectionString("ConStr")));
           //services.AddDbContext<AlbumContext>(options => options.UseSqlServer(Configuration.GetConnectionString("ConStr")));
            services.AddDbContext<CommentsContext>(options => options.UseSqlServer(Configuration.GetConnectionString("ConStr")));
            services.AddAutoMapper(typeof(AutoMapperProfile));
            
            services.AddControllers();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "Demotodo", Version = "v1" });
            });
            //services.AddTransient<IPhotosService, PhotosService>();
             services.AddScoped<ICommentsService, CommentsService>();
           // services.AddScoped<IAlbumService, AlbumService>();
            services.AddScoped<IPhotosService, PhotosService>();
            services.AddScoped<ITodoService, TodoService>();
            services.AddScoped<TodoRepo>();
            services.AddScoped<PhotosRepo>();
            //services.AddScoped<AlbumRepo>();
            services.AddScoped<CommentsRepo>();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "Demotodo v1"));
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
