﻿using Demotodo.IBLL;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Demotodo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommentsContoller : ControllerBase
    {

        private readonly ICommentsService _commentsService;

        public CommentsContoller(ICommentsService commentsService)
        {
            _commentsService = commentsService;
        }

        [HttpPost("CreateComment")]
        public async Task<ActionResult> CreateComment()
        {
            var model = await _commentsService.CreateComment();
            return Ok(model);
        }
        [HttpGet("GetComment")]
        public async Task<ActionResult> GetComment()
        {
            var res = await _commentsService.GetComment();
            return Ok(res);
        }



    }
}
