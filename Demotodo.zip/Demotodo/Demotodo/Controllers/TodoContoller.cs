﻿using Demotodo.IBLL;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Demotodo.Controllers
{

    [Route("api")]
    [ApiController]
    public class TodoController : ControllerBase
    {
        private readonly ITodoService _todoService;

        public TodoController(ITodoService todoService)
        {
            _todoService = todoService;
        }

        [HttpPost("CreateUsers")]
        public async Task<ActionResult> CreateUsers()
        {
            var res = await _todoService.CreateUser();
            return Ok(res);
        }

        [HttpPost("CreateTodo")]
        public async Task<ActionResult> CreateTodo()
        {
            var model = await _todoService.CreateTodo();
            return Ok(model);
        }

        [HttpGet("GetUsers")]
        public async Task<ActionResult> GetUsers()
        {
            var user = await _todoService.GetUsers();
            return Ok(user);
        }

        [HttpGet("GetTodos")]
        public async Task<ActionResult> GetTodos()
        {
            var res = await _todoService.GetToDos();
            return Ok(res);
        }

    }
}
