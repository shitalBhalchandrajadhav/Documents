﻿using Demotodo.IBLL;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Demotodo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Photos1Controller : ControllerBase
    {

            private readonly IPhotosService _photosService;

            public Photos1Controller(IPhotosService photosService)
            {
              _photosService = photosService;
            }

        [HttpPost("CreatePhotos")]
        public async Task<ActionResult> CreatePhotos()
        {
            var model = await _photosService.CreatePhotos();
            return Ok(model);
        }
        [HttpGet("GetPhotos")]
        public async Task<ActionResult> GetPhotos()
        {
            var res = await _photosService.GetPhotos();
            return Ok(res);
        }



    }
}
