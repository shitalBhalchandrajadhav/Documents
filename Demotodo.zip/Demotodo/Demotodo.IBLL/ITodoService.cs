﻿using Demotodo.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demotodo.IBLL
{
    public interface ITodoService
    {
        Task<bool> CreateUser();
        Task<List<User>> GetUsers();
        Task<bool> CreateTodo();
        Task<List<Todo>> GetToDos();

       
    }
}
