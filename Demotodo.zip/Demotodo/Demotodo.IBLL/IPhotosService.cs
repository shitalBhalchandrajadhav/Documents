﻿using Demotodo.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demotodo.IBLL
{
   public  interface IPhotosService
   {
        Task<bool> CreatePhotos();
        Task<List<Photos>> GetPhotos();
       
   }
}
