﻿using Demotodo.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demotodo.IBLL
{
   public interface ICommentsService
   {
        
            Task<bool> CreateComment();
            Task<List<Comments>> GetComment();

        

   }
}
