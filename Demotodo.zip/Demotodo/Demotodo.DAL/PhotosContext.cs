﻿using Demotodo.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demotodo.DAL
{
    public partial class PhotosContext : DbContext
    {
        public PhotosContext(DbContextOptions<PhotosContext> options)
            : base(options)
        {
        }


        public virtual DbSet<Photos> Photoss { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "Latin1_General_CI_AS");





            modelBuilder.Entity<Photos>(entity =>
            {
                entity.ToTable("Photoss");

                entity.Property(e => e.albumId).ValueGeneratedNever();

                entity.Property(e => e.id).HasMaxLength(128);

                entity.Property(e => e.title).HasMaxLength(128);

                entity.Property(e => e.url).HasMaxLength(128);

                entity.Property(e => e.thumbnailUrl).HasMaxLength(128);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}