﻿using Demotodo.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demotodo.DAL
{
    public class TodoRepo
    {
        private readonly TContext _context;

        public TodoRepo(TContext context)   
        {
            _context = context;
        }


        public async Task<List<User>> GetUsers()
        {
            var users = await _context.Users.AsNoTracking().ToListAsync();
            foreach (var user in users)
            {
                user.Address = await _context.Addresses.AsNoTracking().FirstOrDefaultAsync(u => u.UserId == user.Id);
            }
            return users;
        }

        public async Task<bool> CreateUsers(List<User> listOfUsers)
        {
            try
            {
                await DeleteAddress();
                await DeleteTodo();
                await DeleteUsers();

                foreach (var item in listOfUsers)
                {
                    await _context.Users.AddAsync(item);
                    await _context.SaveChangesAsync();
                }
            }
            catch (Exception e)
            {
                throw new Exception("unsussess");
            }
            return true;

        }
        public async Task DeleteUsers()
        {
            var oldUser = await _context.Users.ToListAsync();
            if (oldUser != null && oldUser.Count > 0)
            {
                _context.Users.RemoveRange(oldUser);
                await _context.SaveChangesAsync();
            }

        }
        public async Task DeleteAddress()
        {
            var old = await _context.Addresses.ToListAsync();
            if (old != null && old.Count > 0)
            {
                _context.Addresses.RemoveRange(old);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<bool> CreateAddress(List<Address> listOfAddress)
        {
            try
            {
                await DeleteAddress();
                foreach (var item in listOfAddress)
                {
                    await _context.Addresses.AddAsync(item);
                    await _context.SaveChangesAsync();
                }
            }
            catch (Exception e)
            {
                throw new Exception("unsucess");
            }
            return true;

        }

        public async Task<List<Todo>> GetToDos()
        {
            return await _context.Todos.AsNoTracking().ToListAsync();
        }

        public async Task<bool> CreateTodo(List<Todo> todos)
        {
            try
            {
                await DeleteTodo();

                foreach (var item in todos)
                {
                    await _context.Todos.AddAsync(item);
                    await _context.SaveChangesAsync();
                }
            }
            catch (Exception e)
            {
                throw new Exception("unsuess");
            }
            return true;
        }

        public async Task DeleteTodo()
        {
            var res = await _context.Todos.ToListAsync();
            if (res != null && res.Count > 0)
            {
                _context.Todos.RemoveRange(res);
                await _context.SaveChangesAsync();
            }
        }




    }
}
