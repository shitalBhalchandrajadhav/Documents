﻿using Demotodo.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demotodo.DAL
{
   public partial class CommentsContext : DbContext
   {

        public CommentsContext(DbContextOptions<CommentsContext> options)
                : base(options)
        {
        }


            public virtual DbSet<Comments> Commentss{ get; set; }

            protected override void OnModelCreating(ModelBuilder modelBuilder)
            {
                modelBuilder.HasAnnotation("Relational:Collation", "Latin1_General_CI_AS");





                modelBuilder.Entity<Comments>(entity =>
                {
                    entity.ToTable("Comments");

                    entity.Property(e => e.postId).ValueGeneratedNever();

                    entity.Property(e => e.id).HasMaxLength(128);

                    entity.Property(e => e.name).HasMaxLength(128);

                    entity.Property(e => e.email).HasMaxLength(128);

                    entity.Property(e => e.body).HasMaxLength(128);
                });

                OnModelCreatingPartial(modelBuilder);
            }

            partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
        
   }
}
