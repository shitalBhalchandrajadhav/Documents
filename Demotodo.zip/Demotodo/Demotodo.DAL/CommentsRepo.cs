﻿using Demotodo.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demotodo.DAL
{
    public class CommentsRepo
    {
       private readonly CommentsContext _context;

        public  CommentsRepo(CommentsContext context)
        {
                _context = context;
        }
        public async Task<List<Comments>> GetComment()
        {
                return await _context.Commentss.AsNoTracking().ToListAsync();
        }
        public async Task<bool> CreateComment(List<Comments> comments)
        {
            try
            {
                await DeleteComment();

                foreach (var res in comments)
                {
                    await _context.Commentss.AddAsync(res);
                    await _context.SaveChangesAsync();
                }
            }
            catch (Exception e)
            {
                throw new Exception("unsuess");
            }
                return true;
        }
            public async Task DeleteComment()
            {
                var res = await _context.Commentss.ToListAsync();
                if (res != null && res.Count > 0)
                {
                    _context.Commentss.RemoveRange(res);
                    await _context.SaveChangesAsync();
                }
            }




        

    }
}
