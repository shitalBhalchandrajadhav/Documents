﻿using Demotodo.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demotodo.DAL
{
    
     public class PhotosRepo
     {
        private readonly PhotosContext _context;

        public PhotosRepo(PhotosContext context)
        {
            _context = context;
        }
        
        
        public async Task<List<Photos>> GetPhotos()
        {
            return await _context.Photoss.AsNoTracking().ToListAsync();
        }

        public async Task<bool> CreatePhotos(List<Photos> Photos)
        {
            try
            {
                await DeletePhotos();

                foreach (var res in Photos)
                {
                    await _context.Photoss.AddAsync(res);
                    await _context.SaveChangesAsync();
                }
            }
            catch (Exception e )
            {
                throw new Exception("unsuess");
            }
            return true ;
        }

        public async Task DeletePhotos()
        {
            var res = await _context.Photoss.ToListAsync();
            if (res != null && res.Count > 0)
            {
                _context.Photoss.RemoveRange(res);
                await _context.SaveChangesAsync();
            }
        }




     }
}
