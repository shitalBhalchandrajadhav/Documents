﻿using AutoMapper;
using Demotodo.DAL;
using Demotodo.IBLL;
using Demotodo.Model;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Demotodo.BLL
{
   public  class CommentsService :ICommentsService
    {
            private readonly CommentsRepo _commentsRepo;


            private readonly IMapper mapper;
            private readonly Config _config;
            public CommentsService(CommentsRepo commentsRepo, IMapper mapper, IOptions<Config> Config)
            {
            _commentsRepo = commentsRepo;
                this.mapper = mapper;
                _config = Config.Value;
            }

            public async Task<string> ExecuteGetRequest(string url)
            {
                using var client = new HttpClient();
                client.DefaultRequestHeaders.Add("Accept", "application/json");

                var apiresponse = await client.GetAsync(new Uri(url));
                if (apiresponse.IsSuccessStatusCode)
                {
                    string result = await apiresponse.Content.ReadAsStringAsync();
                    return result;
                }
                throw new Exception(" Failed");
            }

            public async Task<bool> CreateComment()
            {
                var url = _config.urlcomment;
                var res = await ExecuteGetRequest(url);
                var task = JsonConvert.DeserializeObject<List<Comments>>(res);
                return await _commentsRepo.CreateComment(task);
                //if (isSuccess is true)
                //{
                //    return true;
                //}
                //else
                //{
                //    return false;
                //}
            }

            public async Task<List<Comments>> GetComment()
            {
                var req = await _commentsRepo.GetComment();
                return req;
            }

   }
}
