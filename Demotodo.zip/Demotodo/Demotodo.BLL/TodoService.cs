﻿using AutoMapper;
using Demotodo.DAL;
using Demotodo.IBLL;
using Demotodo.Model;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Demotodo.BLL
{
    public class TodoService : ITodoService
    {
        private readonly TodoRepo _todoRepo;

       

        private readonly IMapper mapper;
        private readonly Config _config;
        public TodoService(TodoRepo todoRepo, IMapper mapper, IOptions<Config> Config)
        {
            _todoRepo = todoRepo;
            this.mapper = mapper;
            _config = Config.Value;
        }

        async Task<string> ExecuteGetRequest(string url)
        {
            using var client = new HttpClient();
            client.DefaultRequestHeaders.Add("Accept", "application/json");

            var apiresponse = await client.GetAsync(new Uri(url));
            if (apiresponse.IsSuccessStatusCode)
            {
                string result = await apiresponse.Content.ReadAsStringAsync();
                return result;
            }
            throw new Exception("Api Failed");
        }

        public async Task<bool> CreateUser()
        {
           var url = _config.urluser;
           
            var res = await ExecuteGetRequest(url);
            var users = JsonConvert.DeserializeObject<List<User>>(res);
            users.ForEach(u => u.Address.UserId = u.Id);
            var isSuccess = await _todoRepo.CreateUsers(users);
            if (isSuccess is true)
            {
                var addresses = users.Select(a => a.Address).ToList();
                isSuccess = await _todoRepo.CreateAddress(addresses);
                return isSuccess;
            }
            else
            {
                return false;
            }
        }

        public async Task<List<User>> GetUsers()
        {
            var result = await _todoRepo.GetUsers();
            return result;
        }

        public async Task<bool> CreateTodo()
        {
            var urltodo = _config.urltodo;
            var res = await ExecuteGetRequest(urltodo);
            var todos = JsonConvert.DeserializeObject<List<Todo>>(res);
            var isSuccess = await _todoRepo.CreateTodo(todos);
            if (isSuccess is true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public async Task<List<Todo>> GetToDos()
        {
            var todos = await _todoRepo.GetToDos();
            return todos;
        }
    }
}
