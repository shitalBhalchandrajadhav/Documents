﻿using AutoMapper;
using Demotodo.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demotodo.BLL.AutoMapper
{
   public  class AutoMapperProfile : Profile
   {
        public AutoMapperProfile()
        {
            CreateMap<Address, Address>();
            CreateMap<Todo, Todo>();
            CreateMap<User, User>();
            CreateMap<Photos, Photos>();
           
            CreateMap<Comments, Comments>();
        }
    }

}

