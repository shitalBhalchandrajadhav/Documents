﻿using AutoMapper;
using Demotodo.DAL;
using Demotodo.IBLL;
using Demotodo.Model;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Demotodo.BLL
{
   public class PhotosService : IPhotosService
   {
            private readonly PhotosRepo _photosRepo;

           
            private readonly IMapper mapper;
            private readonly Config _config;
            public PhotosService(PhotosRepo photosRepo, IMapper mapper, IOptions<Config> Config)
            {
                _photosRepo = photosRepo;
                this.mapper = mapper;
                _config = Config.Value;
            }

             public async Task<string> ExecuteGetRequest(string url)
            {
                using var client = new HttpClient();
                client.DefaultRequestHeaders.Add("Accept", "application/json");

               var apiresponse = await client.GetAsync(new Uri(url));
                if (!apiresponse.IsSuccessStatusCode)
                {

                throw new Exception(" Failed");
            }

            string result = await apiresponse.Content.ReadAsStringAsync();
            return result;
        }

             public async Task<bool> CreatePhotos()
             {
                var urlphotos = _config.urlphotos;
                var res = await ExecuteGetRequest(urlphotos);
                var task = JsonConvert.DeserializeObject<List<Photos>>(res);
                return await _photosRepo.CreatePhotos(task);
                //if (isSuccess is true)
                //{
                //    return true;
                //}
                //else
                //{
                //    return false;
                //}
             }

        public async Task<List<Photos>> GetPhotos()
        {
            return await _photosRepo.GetPhotos();
        }

       
   }
}
