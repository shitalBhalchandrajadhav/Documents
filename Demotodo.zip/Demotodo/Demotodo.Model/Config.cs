﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demotodo.Model
{
    public class Config
    {
        //public object urlalbums;

        public  string urluser { get;  set;}
         public string urltodo { get;set;}
        public string urlphotos { get; set; }
       
        public string urlcomment { get; set; }
    }
}
