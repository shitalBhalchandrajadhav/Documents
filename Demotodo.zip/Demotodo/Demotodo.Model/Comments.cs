﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demotodo.Model
{
   public partial class Comments
    {

     public int postId { get; set; }
      
     public int id { get; set; }

     public string name { get; set; }
     public string email { get; set; }
     public  String  body { get; set; }
   
    }
}
